
Polymorphism : Compile time
					Function overloading - Done
					operator overloading - 
				Runtime - Virtual Functions - RTP	

Operator Overloading...
		Why OO? 
			Extend the meaning of the existing operators to be used with the UDT.
			You cannot change the meaning of an existing operator - 
				cannot make a unary operator work like a binary or otherwise...
				
		
class player
{
	int age,runs,wkts;
	 
	public:	
	player(int a, int r, int w, char* n)
	{
		age = a;
		runs = r;
		wkts = w;
		name = (char*) malloc(20);
		strcpy(name, n);
	}
	int operator++() // prefix // incrementing and returing...
	{
		age++ ;		
		return age;
	}		
	
	int operator++(int dummy) // postfix //return and incrementing
	{
		int temp = age;
		age++ ;		
		return temp;
	}		
	void incrementage()
	{
		age++;
		
	}
	//void incrementwkts(){}
	//void incrementnom() {}
	
};
Unary  : one operand
Binary : two operands

void main()
{
	int i = 100, j = 200;
	++i;
	i++;//post increment 
		1. Compiler checks to see the type of the operator - unary (++)
		2. No. of operands - 1 - fine...
		3. What is the data type of the identifier on which the operator is used ; (int) PDT
		4. compiler knows how to apply this operator on a pdt... incrememt the value at the address of 
			// identifier by 1
			
	cout << i << endl ; // 101
	
	player vijay(28,800,2,"Murali");
	// how to increment the age of a player by 1;
	virat.age++; // this will work only if age is a public member . what if it is a private member?
	virat.incrementage(); // this is fine... 
	
	virat++ ; // easier.. my meaning of ++ for the player class is to increment the age by 1.... OO (++)
		1. Compiler checks to see the type of the operator - unary (++)
		2. No. of operands - 1 - fine...
		3. What is the data type of the identifier on which the operator is used ; player
		4. Compiler will check to see whether there is a overloaded function for this operator.. if yes,
		5. Check to see if the usage is like postfix or prefix.
		6. if postfix, then map this call to virat.operator++(int);
		7. if prefix, then map this call to virat.operator++();
		
	++virat; // will this work?
		1. Compiler checks to see the type of the operator - unary (++)
		2. No. of operands - 1 - fine...
		3. What is the data type of the identifier on which the operator is used ; player
		4. Compiler will check to see whether there is a overloaded function for this operator.. if yes,
		5. Check to see if the usage is like postfix or prefix.
		6. if postfix, then map this call to virat.operator++(int);
		7. if prefix, then map this call to virat.operator++();
		
	// on VS, the same overloaded function will work for both post and pre.
	// on G++, the compiler will throw an error on one of the uses..
	
	
	int age = 28 ;
	cout << age++ ; // 28
	cout << ++age; // 30 
	
	cout << virat++ << endl ; // return and then increment
	cout << ++virat << endl ; // increment and then return...
}